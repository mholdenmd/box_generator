import './App.css';
import BoxesForm from './components/boxes';

function App() {
  return (
    <div className="App">
      <div>

      <h1>Box Generator</h1>
      <BoxesForm></BoxesForm>
      </div>
    </div>
  );
}

export default App;
